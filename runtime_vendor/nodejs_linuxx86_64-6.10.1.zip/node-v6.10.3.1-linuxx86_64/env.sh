SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export PATH="${SCRIPT_DIR}"/bin:${PATH}
echo "using node `node --version`"
echo "using npm `npm --version`"
